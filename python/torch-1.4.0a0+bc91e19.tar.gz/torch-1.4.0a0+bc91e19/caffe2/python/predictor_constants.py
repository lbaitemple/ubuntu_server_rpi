## @package predictor_constants
# Module caffe2.python.predictor_constants
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import caffe2.proto.predictor_consts_pb2 as predictor_consts

predictor_constants = predictor_consts.PredictorConsts()
